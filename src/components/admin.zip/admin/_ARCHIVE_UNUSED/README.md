# About last time

Last round I quarantined `reports/` and `pages/ReportsPage.jsx` as dead code.
That was wrong — I didn't have `AdminPage.jsx` (the real router) yet, so I
couldn't see that `pages/ReportsPage.jsx` (now moved to `reports/ReportsPage.jsx`)
*is* actually imported and used. Sorry for the confusion. This round is built
against `AdminPage.jsx` as the source of truth, so what's in here now is
genuinely unused — I checked every one against the real entry point.

## What's in here and why

- **AdminDashboard.jsx** (old root file) — `AdminPage.jsx` was still importing
  this simple version (stats + 3 pie charts) instead of the newer, more complete
  `dashboard/Dashboard.jsx` (stats + summary + charts + alerts + recent reports +
  quick actions) that was already built out in the `dashboard/` folder but never
  wired in. I switched `AdminPage.jsx` over to the newer one.

- **AdminModals/DetailsModal.jsx** — not imported anywhere. `AdminModals/FormModal.jsx`
  (the one you use to add a new report) is untouched and still in place.

- **Admintables/** (all 4 files, including `VolunteerApplicationsTable.jsx`) —
  zero references anywhere in the codebase. The tables that are actually live are
  the similarly-named ones inside `reports/emergency/`, `reports/assistance/`,
  `reports/pettyCrime/`. There's also no "volunteer" feature anywhere else in the
  app (no data, no API call, no view) — looks like a feature that was started and
  abandoned.

- **DashboardHeader.jsx, DashboardOverview.jsx** — sitting in `dashboard/` but
  never imported by `Dashboard.jsx` or anything else.

- **AnnouncementForm.jsx** — not used; `CreateAnnouncementView.jsx` is the one
  actually wired into `AnnouncementsPage.jsx` and it doesn't use this at all.

- **announcementService.js** — an axios-style wrapper (`api.post`, `api.put`) that
  assumed `Services/api.js` had a default axios export. It doesn't (it's a plain
  `fetch()`-based module of named exports), so this file could never have worked
  as written. Its announcement create/update/preview functionality is already
  covered by `Services/api.js`, which is now what `AnnouncementsTable.jsx` and
  `CreateAnnouncementView.jsx` both use.

- **UserDetails.jsx, users_index.js** — empty (0 bytes), unused.

- **pages_AnnouncementsPage_empty.jsx, pages_LogsPage_empty.jsx,
  pages_NotificationPage_empty.jsx** — empty (0 bytes), unused. The `pages/`
  folder they lived in is gone now; the one real file it had
  (`ReportsPage.jsx`) moved to `reports/ReportsPage.jsx` since that's where it
  actually belongs.

- **pages_DashboardPage_wrapper.jsx** — a 4-line wrapper that just rendered the
  old `Dashboard`. No longer needed since `AdminPage.jsx` renders
  `dashboard/Dashboard.jsx` directly now.

I also dropped three completely empty, file-less folders: `tables/`,
`notifications/`, `settings/`.

## What I'd recommend

Once you've spot-checked the app and confirmed nothing's missing, delete this
whole `_ARCHIVE_UNUSED` folder.
